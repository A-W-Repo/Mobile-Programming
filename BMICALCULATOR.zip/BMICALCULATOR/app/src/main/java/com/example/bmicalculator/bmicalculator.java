package com.example.bmicalculator;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.DecimalFormat;

public class bmicalculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmicalculator);
        TextView bmicalc = (TextView)findViewById(R.id.txtbmi);
        ImageView image = (ImageView)findViewById(R.id.imageView2);
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        double intweight = sharedPref.getInt("key1", 0);
        double intheight = sharedPref.getInt("key2", 0);
        double bmi =  (intweight*703)/(intheight*intheight);
        DecimalFormat calcu = new DecimalFormat("###.#");
        bmicalc.setText("Your body mass index is: " +calcu.format(bmi));

    }
}