package com.example.bmicalculator;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
   int intweight;
   int intheight;
   int intminuteswalked2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText weight = (EditText) findViewById(R.id.txtweight);
        final EditText height = (EditText)findViewById(R.id.txtheight);
        final EditText time = (EditText)findViewById(R.id.txttime);

        Button button = (Button)findViewById(R.id.btnBMI);
        final SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        button.setOnClickListener(new View.OnClickListener(){

            @Override
          public void onClick(View v){
                intweight = Integer.parseInt(weight.getText().toString());
                intheight = Integer.parseInt(height.getText().toString());
                intminuteswalked2 = Integer.parseInt(time.getText().toString());
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putInt("key1", intweight);
                editor.putInt("key2", intheight);
                editor.putInt("key3", intminuteswalked2);
                editor.commit();
                startActivity(new Intent(MainActivity.this, bmicalculator.class));
         }
     });
  }
}