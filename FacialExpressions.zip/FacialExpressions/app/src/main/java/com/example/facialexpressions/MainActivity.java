package com.example.facialexpressions;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    AnimationDrawable facesAnimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imgFrame=(ImageView)findViewById(R.id.imgFaces);
        imgFrame.setBackgroundResource(R.drawable.animation);
        facesAnimation=(AnimationDrawable)imgFrame.getBackground();
        Button button1 = (Button) findViewById(R.id.btnStart);
        button1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick (View v) {
                facesAnimation.start( );

            }
        });

    }
}
